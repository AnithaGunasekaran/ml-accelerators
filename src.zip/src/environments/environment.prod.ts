export const environment = {
  production: true,
  usecaseId: "1",
<<<<<<< HEAD
  apiEndPoint: 'https://54.85.63.69/api/v1',
  public:'https://54.85.63.69',
=======
  apiEndPoint: 'http://localhost/api/v1',
  public:'http://localhost',
>>>>>>> bc139603ba31f9248d196f37845c140add54256e
  firebase: {
    apiKey: 'AIzaSyDP7ulefaLJ8fz5MXZZkoD9FzN5h6MI7sQ',
    authDomain: 'ml-acc.firebaseapp.com',
    databaseURL: 'https://ml-acc.firebaseio.com',
    projectId: 'ml-acc',
    storageBucket: 'ml-acc.appspot.com',
    messagingSenderId: '529743086184'
  }
};
