export class JSONResponse {
    code: number;
    result: string
}