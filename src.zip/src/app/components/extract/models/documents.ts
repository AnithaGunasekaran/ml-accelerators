export class Documents {
    id: string;
    file_name: string;
    link: string;
    template_name: string;
    status: string;
    json: string;
    preview: string;
    pdfLink: string
}
