export class Templates {
    id: number;
    name: string;
    image: string;
    link: string;
    preview: string
}
