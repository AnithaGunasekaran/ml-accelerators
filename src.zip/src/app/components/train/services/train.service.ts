import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import { Metadata } from '../models/metadata';

@Injectable({
  providedIn: 'root'
})
export class TrainService {

  apiEndPoint = environment.apiEndPoint;

  constructor(private httpClient:HttpClient) { }

  getMetaData(usecaseId:string, templateName:string){
    let params = {'use_case_id': usecaseId, 'template_name': templateName}
    return this.httpClient.get(`${this.apiEndPoint}/getMetaData`, {params:params}).toPromise()
      .then(res => <Metadata>res)
      .then(data => {  return data; });
  }

  getTrainingPdfs(usecaseId:string,templateName:string){
    let params = {'use_case_id': usecaseId, 'template_name': templateName}
    return this.httpClient.get(`${this.apiEndPoint}/getTrainPdfs`, {params:params}).toPromise()
      .then(res => res)
      .then(data => {  return data; });
  }


  postTrainModel(usecaseId:string, templateName:string, json:string){
    let params = {'use_case_id': usecaseId, 'template_name': templateName};
<<<<<<< HEAD
    return this.httpClient.post(`${this.apiEndPoint}/train`, json, {params: params,responseType: 'text',observe: 'response'}).toPromise()
    .then((res)=>{
        console.log(res);
        return res;
    });
=======
    return this.httpClient.post(`${this.apiEndPoint}/train`, json, {params: params,responseType: 'text'}).toPromise()
    .then(res => res)
    .then(data => { console.log("Data",data); return data; });
>>>>>>> bc139603ba31f9248d196f37845c140add54256e
  }

  getAutoPopulate(usecaseId:string, templateName:string){
   
    let params = {'use_case_id': usecaseId, 'template_name': templateName}
    console.log(params)
    return this.httpClient.get(`${this.apiEndPoint}/getDefaultData`, {params: params}).toPromise()
    .then(res => res)
    .then(data => {  return data; });

  }

}
