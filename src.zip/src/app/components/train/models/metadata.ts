export class Metadata {
    code: number;
    result: any;
}
